#!/bin/bash
# quick coolbooter script for dummies made in like 5 minutes
echo "Coolbooter script made by Nobbele who also go by the name 4pplecracker."
echo "Follow me on twitter @4pplecracker. Report any bugs/erorrs with this program there.
"
echo "Type 'install', 'uninstall' or boot followed by [ENTER]"

read option

if [ $option == "install" ]
   then
	echo "Which version would you like to install? (only ios 5, 6 and 7 are supported)"
	read version
	coolbootercli $version
elif [ $option == "uninstall" ]
	then
	 coolbootercli -u
elif [ $option == "boot" ]
	then
	 coolbootercli -b
else
	echo "you didn't type it correctly"
fi
